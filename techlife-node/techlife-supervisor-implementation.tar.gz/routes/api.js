/**
 * TECH-Life REST API (Node/Express edition). Same route contract as the
 * previous PHP api/v1/index.php -- every handler calls into the
 * Reporting Services, never writes its own ad-hoc aggregation SQL.
 */
const express = require('express');
const router = express.Router();
const { pool } = require('../src/db');
const { requireAuth } = require('../src/auth');
const agentReportService = require('../src/services/agentReportService');
const queueReportService = require('../src/services/queueReportService');
const didReportService = require('../src/services/didReportService');
const campaignReportService = require('../src/services/campaignReportService');
const ivrReportService = require('../src/services/ivrReportService');
const config = require('../config/config');

router.use(requireAuth);

// ---- Outbound DND preflight ----
router.post('/dnd/check', async (req, res) => {
    const u = req.session.user;
    const raw = typeof req.body?.phone_number === 'string'
        ? req.body.phone_number.trim()
        : '';

    // Accept only dialable characters; normalize to digits for matching.
    if (!raw || !/^[+0-9().\-\s]+$/.test(raw)) {
        return res.status(400).json({ error: 'invalid_phone_number' });
    }

    const phone = raw.replace(/\D/g, '');
    if (phone.length < 7 || phone.length > 15) {
        return res.status(400).json({ error: 'invalid_phone_number' });
    }

    try {
        const result = await pool.query(
            `SELECT id
             FROM do_not_call_entries
             WHERE tenant_id = $1
               AND campaign_id IS NULL
               AND regexp_replace(phone_number, '\\D', '', 'g') = $2
             LIMIT 1`,
            [u.tenantId, phone]
        );

        if (result.rowCount > 0) {
            return res.status(403).json({
                allowed: false,
                error: 'do_not_call',
                message: 'This number is on your organisation’s Do Not Call list.'
            });
        }

        return res.json({ allowed: true });
    } catch (err) {
        console.error('DND preflight failed:', err.message);
        return res.status(503).json({ allowed: false, error: 'dnd_check_unavailable' });
    }
});

function dateRange(req) {
    const from = req.query.from || new Date().toISOString().slice(0, 10) + ' 00:00:00';
    const to = req.query.to || new Date().toISOString().slice(0, 10) + ' 23:59:59';
    return [from, to];
}

// ---- SIP credentials for the WebRTC workspace ----
router.get('/agents/:id/sip-credentials', async (req, res) => {
    const u = req.session.user;
    const isSelf = u.agentId === req.params.id;
    const isPrivileged = ['supervisor', 'admin', 'superadmin'].some((r) => u.roles.includes(r));
    if (!isSelf && !isPrivileged) return res.status(403).json({ error: 'forbidden' });

    const result = await pool.query(
        `SELECT ag.extension, ag.sip_username, ag.sip_password, ag.provisioning_status,
                COALESCE(t.sip_domain, $3) AS sip_domain
         FROM agents ag JOIN tenants t ON t.id = ag.tenant_id
         WHERE ag.tenant_id = $1 AND ag.id = $2`,
        [u.tenantId, req.params.id, config.wazo.sipDomain]
    );
    const row = result.rows[0];
    if (!row) return res.status(404).json({ error: 'agent_not_found' });
    if (row.provisioning_status !== 'provisioned' && row.provisioning_status !== 'manual') {
        return res.status(409).json({ error: 'not_provisioned', status: row.provisioning_status });
    }
    res.json({
        extension: row.extension,
        sip_username: row.sip_username,
        sip_password: row.sip_password,
        sip_domain: row.sip_domain,
        ws_uri: config.wazo.sipWsUri,
    });
});


// ---- Completed calls available to the agent disposition panel ----
router.get('/agents/:id/completed-calls', async (req, res) => {
    const u = req.session.user;
    const agentId = req.params.id;
    const isPrivileged = ['supervisor', 'admin', 'superadmin'].some(
        r => Array.isArray(u.roles) && u.roles.includes(r)
    );

    if (u.agentId !== agentId && !isPrivileged) {
        return res.status(403).json({ error: 'forbidden' });
    }

    if (!agentId) {
        return res.status(400).json({ error: 'agent_id_required' });
    }

    try {
        const result = await pool.query(
            `SELECT c.id, c.direction::text AS direction,
                    CASE WHEN c.direction::text = 'outbound'
                         THEN c.to_number ELSE c.from_number END AS phone_number,
                    c.start_time, c.end_time, c.campaign_id,
                    d.code AS disposition_code
             FROM calls c
             LEFT JOIN dispositions d ON d.id = c.disposition_id
             WHERE c.tenant_id = $1
               AND c.agent_id = $2
               AND c.status::text = 'completed'
               AND c.end_time IS NOT NULL
             ORDER BY c.end_time DESC
             LIMIT 20`,
            [u.tenantId, agentId]
        );

        return res.json({ results: result.rows });
    } catch (err) {
        console.error('Completed calls lookup failed:', err.message);
        return res.status(500).json({ error: 'completed_calls_lookup_failed' });
    }
});

// ---- Real-agent call disposition, DNC and callback scheduling ----
router.post('/agents/:id/disposition', async (req, res) => {
    const u = req.session.user;
    const agentId = req.params.id;
    const callId = typeof req.body?.call_id === 'string' ? req.body.call_id.trim() : '';
    const code = typeof req.body?.code === 'string' ? req.body.code.trim().toUpperCase() : '';
    const notes = typeof req.body?.notes === 'string' ? req.body.notes.trim().slice(0, 4000) : '';
    const callbackAt = req.body?.callback_at;
    const dncScope = req.body?.dnc_scope === 'campaign' ? 'campaign' : 'tenant';

    const isPrivileged = ['supervisor', 'admin', 'superadmin'].some(
        r => Array.isArray(u.roles) && u.roles.includes(r)
    );
    if (u.agentId !== agentId && !isPrivileged) {
        return res.status(403).json({ error: 'forbidden' });
    }

    if (!callId || !/^[0-9a-f-]{36}$/i.test(callId)) {
        return res.status(400).json({ error: 'valid_call_id_required' });
    }
    if (!['DND', 'FOLLOW_UP', 'TRANSFER', 'NORMAL', 'OTHERS', 'SALEDONE'].includes(code)) {
        return res.status(422).json({ error: 'invalid_disposition' });
    }

    let parsedCallback = null;
    if (code === 'FOLLOW_UP') {
        parsedCallback = typeof callbackAt === 'string' ? new Date(callbackAt) : null;
        if (!parsedCallback || Number.isNaN(parsedCallback.getTime()) || parsedCallback <= new Date()) {
            return res.status(422).json({ error: 'valid_future_callback_at_required' });
        }
    }

    const client = await pool.connect();
    try {
        await client.query('BEGIN');

        const callResult = await client.query(
            `SELECT c.id, c.agent_id, c.campaign_id, c.contact_id,
                    c.status::text AS status,
                    CASE WHEN c.direction::text = 'outbound'
                         THEN c.to_number ELSE c.from_number END AS phone_number
             FROM calls c
             WHERE c.tenant_id = $1 AND c.id = $2
             FOR UPDATE`,
            [u.tenantId, callId]
        );

        const call = callResult.rows[0];
        if (!call || call.agent_id !== agentId) {
            await client.query('ROLLBACK');
            return res.status(404).json({ error: 'call_not_found_for_agent' });
        }

        if (call.status !== 'completed') {
            await client.query('ROLLBACK');
            return res.status(409).json({ error: 'call_not_completed' });
        }

        const dispResult = await client.query(
            `SELECT id FROM dispositions
             WHERE tenant_id = $1 AND code = $2 AND channel::text = 'voice'
               AND is_active = TRUE
             LIMIT 1`,
            [u.tenantId, code]
        );
        if (!dispResult.rowCount) {
            await client.query('ROLLBACK');
            return res.status(422).json({ error: 'disposition_not_configured' });
        }

        await client.query(
            `UPDATE calls
             SET disposition_id = $3
             WHERE tenant_id = $1 AND id = $2`,
            [u.tenantId, callId, dispResult.rows[0].id]
        );

        if (code === 'DND') {
            const rawPhone = String(call.phone_number || '').trim();
            const phone = rawPhone.replace(/\D/g, '');
            if (phone.length < 7 || phone.length > 15) {
                await client.query('ROLLBACK');
                return res.status(422).json({ error: 'call_has_no_valid_phone_number' });
            }

            const campaignId = dncScope === 'campaign' ? call.campaign_id : null;
            if (dncScope === 'campaign' && !campaignId) {
                await client.query('ROLLBACK');
                return res.status(422).json({ error: 'call_has_no_campaign_for_campaign_dnc' });
            }

            await client.query(
                `INSERT INTO do_not_call_entries
                    (tenant_id, phone_number, campaign_id, reason, created_by)
                 VALUES ($1,$2,$3,$4,$5)
                 ON CONFLICT DO NOTHING`,
                [u.tenantId, phone, campaignId, notes || 'Agent marked Do Not Call', u.id]
            );
        }

        if (code === 'FOLLOW_UP') {
            const rawPhone = String(call.phone_number || '').trim();
            const phone = rawPhone.replace(/\D/g, '');
            if (phone.length < 7 || phone.length > 15) {
                await client.query('ROLLBACK');
                return res.status(422).json({ error: 'call_has_no_valid_phone_number' });
            }

            await client.query(
                `INSERT INTO agent_callbacks
                    (tenant_id, agent_id, call_id, campaign_id, phone_number,
                     due_at, status, notes)
                 VALUES ($1,$2,$3,$4,$5,$6,'scheduled',$7)`,
                [u.tenantId, agentId, callId, call.campaign_id, phone, parsedCallback.toISOString(), notes || null]
            );
        }

        await client.query(
            `INSERT INTO call_events (tenant_id, call_id, event_type, event_time, agent_id, payload_json)
             VALUES ($1,$2,$3,now(),$4,$5::jsonb)`,
            [u.tenantId, callId, 'DISPOSITION_SET', agentId,
             JSON.stringify({ code, notes, dnc_scope: code === 'DND' ? dncScope : null })]
        );

        await client.query('COMMIT');
        return res.json({ ok: true, code });
    } catch (err) {
        await client.query('ROLLBACK').catch(() => {});
        console.error('Disposition save failed:', err.message);
        return res.status(500).json({ error: 'disposition_save_failed' });
    } finally {
        client.release();
    }
});

// ---- CRM screen-pop config, for the agent workspace to fetch on load ----
router.get('/crm/config', async (req, res) => {
    const u = req.session.user;
    const result = await pool.query(
        `SELECT popup_enabled, trigger_event, popup_mode, url_template
         FROM crm_integrations WHERE tenant_id = $1 AND is_active = TRUE AND popup_enabled = TRUE
         ORDER BY created_at LIMIT 1`,
        [u.tenantId]
    );
    res.json(result.rows[0] || { popup_enabled: false });
});

// ---- Agent status ----
router.get('/agents/:id/status', async (req, res) => {
    const u = req.session.user;
    const result = await pool.query(
        `SELECT status, started_at FROM agent_status_events
         WHERE tenant_id = $1 AND agent_id = $2 AND ended_at IS NULL ORDER BY started_at DESC LIMIT 1`,
        [u.tenantId, req.params.id]
    );
    res.json(result.rows[0] || { status: 'offline' });
});

router.post('/agents/:id/status', async (req, res) => {
    const u = req.session.user;
    const { status, reason_code, queue_id } = req.body;
    const validStatuses = ['login','logout','available','break','lunch','tea','training',
        'meeting','system_issue','personal_break','after_call_work','offline','custom'];
    if (!validStatuses.includes(status)) return res.status(422).json({ error: 'invalid_status' });

    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        await client.query(
            `UPDATE agent_status_events SET ended_at = now() WHERE tenant_id = $1 AND agent_id = $2 AND ended_at IS NULL`,
            [u.tenantId, req.params.id]
        );
        await client.query(
            `INSERT INTO agent_status_events (tenant_id, agent_id, queue_id, status, reason_code, started_at, source)
             VALUES ($1,$2,$3,$4,$5,now(),'node_ui')`,
            [u.tenantId, req.params.id, queue_id || null, status, reason_code || null]
        );
        await client.query('COMMIT');
        res.json({ ok: true });
    } catch (e) {
        await client.query('ROLLBACK');
        res.status(500).json({ error: 'server_error' });
    } finally {
        client.release();
    }
});

// ---- Reports ----
router.get('/reports/agents/hourly', async (req, res) => {
    const u = req.session.user;
    const [from, to] = dateRange(req);
    res.json(await agentReportService.hourly(u.tenantId, req.query.agent_id || '', from, to));
});

router.get('/reports/agents/live', async (req, res) => {
    res.json(await agentReportService.liveStatuses(req.session.user.tenantId));
});

router.get('/reports/agents/:id/performance', async (req, res) => {
    const [from, to] = dateRange(req);
    res.json(await agentReportService.performance(req.session.user.tenantId, req.params.id, from, to));
});

router.get('/reports/queues', async (req, res) => {
    const [from, to] = dateRange(req);
    res.json(await queueReportService.summary(req.session.user.tenantId, from, to));
});
router.get('/reports/queues/live', async (req, res) => {
    res.json(await queueReportService.liveSnapshot(req.session.user.tenantId));
});

// Active calls right now (ringing/answered, not yet ended), with enough
// context for the supervisor dashboard to show Listen/Whisper/Barge
// buttons and filter by queue/campaign.
router.get('/reports/calls/live', async (req, res) => {
    const t = req.session.user.tenantId;
    const { queue_id, campaign_id } = req.query;
    const where = ["c.tenant_id = $1", "c.status IN ('ringing','answered')", 'c.end_time IS NULL'];
    const params = [t];
    let idx = 2;
    if (queue_id) { where.push(`c.queue_id = $${idx++}`); params.push(queue_id); }
    if (campaign_id) { where.push(`c.campaign_id = $${idx++}`); params.push(campaign_id); }

    const result = await pool.query(
        `SELECT c.id, c.status, c.direction, c.start_time, c.from_number, c.to_number,
                u.full_name AS agent_name, q.name AS queue_name, camp.name AS campaign_name
         FROM calls c
         LEFT JOIN agents ag ON ag.id = c.agent_id
         LEFT JOIN users u ON u.id = ag.user_id
         LEFT JOIN queues q ON q.id = c.queue_id
         LEFT JOIN campaigns camp ON camp.id = c.campaign_id
         WHERE ${where.join(' AND ')}
         ORDER BY c.start_time DESC`,
        params
    );
    res.json(result.rows);
});
router.get('/reports/queues/:id/hourly', async (req, res) => {
    const [from, to] = dateRange(req);
    res.json(await queueReportService.hourly(req.session.user.tenantId, req.params.id, from, to));
});

router.get('/reports/campaigns/:id', async (req, res) => {
    const [from, to] = dateRange(req);
    res.json(await campaignReportService.summary(req.session.user.tenantId, req.params.id, from, to));
});

router.get('/reports/dids', async (req, res) => {
    const [from, to] = dateRange(req);
    res.json(await didReportService.summary(req.session.user.tenantId, from, to));
});
router.get('/reports/dids/:id/hourly', async (req, res) => {
    const [from, to] = dateRange(req);
    res.json(await didReportService.hourly(req.session.user.tenantId, req.params.id, from, to));
});

router.get('/ivr-sessions/call/:callId/journey', async (req, res) => {
    res.json(await ivrReportService.journeyForCall(req.session.user.tenantId, req.params.callId));
});
router.get('/reports/ivr/:menuId', async (req, res) => {
    const [from, to] = dateRange(req);
    const t = req.session.user.tenantId;
    res.json({
        hourly: await ivrReportService.hourly(t, req.params.menuId, from, to),
        options: await ivrReportService.optionPopularity(t, req.params.menuId, from, to),
    });
});

// ---- Call Monitoring: Listen / Whisper / Barge ----
// Supervisor/admin only. See src/callMonitoring.js for the important
// caveat: this requires a specific Wazo dialplan (ChanSpy) context that
// can't be verified from this environment -- see INSTALL.md.
router.post('/calls/:id/monitor', async (req, res) => {
    const u = req.session.user;
    if (!['supervisor', 'admin', 'superadmin'].some((r) => u.roles.includes(r))) {
        return res.status(403).json({ error: 'forbidden' });
    }
    const mode = req.body.mode;
    try {
        const callMonitoring = require('../src/callMonitoring');
        const result = await callMonitoring.startMonitoring(u.tenantId, u.id, req.params.id, mode);
        res.json({ ok: true, ...result });
    } catch (e) {
        res.status(400).json({ error: e.message });
    }
});

router.post('/monitoring-sessions/:id/stop', async (req, res) => {
    const u = req.session.user;
    if (!['supervisor', 'admin', 'superadmin'].some((r) => u.roles.includes(r))) {
        return res.status(403).json({ error: 'forbidden' });
    }
    try {
        const callMonitoring = require('../src/callMonitoring');
        await callMonitoring.stopMonitoring(u.tenantId, req.params.id);
        res.json({ ok: true });
    } catch (e) {
        res.status(400).json({ error: e.message });
    }
});

// ---- Calls list (JSON) ----
router.get('/calls', async (req, res) => {
    const u = req.session.user;
    const [from, to] = dateRange(req);
    const page = Math.max(1, parseInt(req.query.page || '1', 10));
    const perPage = 50;
    const offset = (page - 1) * perPage;

    const where = ['tenant_id = $1', 'start_time BETWEEN $2 AND $3'];
    const params = [u.tenantId, from, to];
    let idx = 4;
    for (const f of ['agent_id', 'queue_id', 'campaign_id', 'did_id', 'status', 'direction']) {
        if (req.query[f]) { where.push(`${f} = $${idx++}`); params.push(req.query[f]); }
    }
    const result = await pool.query(
        `SELECT id, agent_id, queue_id, campaign_id, did_id, direction, status,
                start_time, answer_time, end_time, talk_seconds, wait_seconds, hangup_cause
         FROM calls WHERE ${where.join(' AND ')} ORDER BY start_time DESC LIMIT ${perPage} OFFSET ${offset}`,
        params
    );
    res.json({ page, results: result.rows });
});

module.exports = router;
